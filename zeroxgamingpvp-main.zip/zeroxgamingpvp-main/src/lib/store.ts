export interface Pack {
  id: string;
  name: string;
  description: string;
  type: string;
  image: string;
  downloadLink: string;
  fpsInfo?: string;
}

export interface Player {
  id: string;
  name: string;
  rank: "bronze" | "silver" | "platinum" | "diamond" | "pro";
  category: "sword" | "crystal";
  score: number;
}

export interface User {
  username: string;
  password: string;
  role: "member" | "admin";
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

export interface SiteData {
  bedrockPacks: Pack[];
  javaPacks: Pack[];
  players: Player[];
  users: User[];
  socialLinks: SocialLink[];
  bio: string;
  avatarUrl: string;
  musicUrl: string;
}

const DEFAULT_DATA: SiteData = {
  bio: "Pro Minecraft PvP Player | Resource Pack Creator | Content Creator",
  avatarUrl: "",
  musicUrl: "",
  bedrockPacks: [
    { id: "1", name: "ZeroxPvP v3", description: "FPS Boost + Clean PvP textures cho Bedrock Edition", type: "PvP", image: "", downloadLink: "#", fpsInfo: "+80 FPS" },
    { id: "2", name: "ZeroxUI Pack", description: "Custom UI hiện đại, tối ưu cho mobile & PC", type: "UI", image: "", downloadLink: "#", fpsInfo: "+50 FPS" },
    { id: "3", name: "ZeroxFPS Boost", description: "Tối ưu FPS cực mạnh, giảm lag đáng kể", type: "FPS", image: "", downloadLink: "#", fpsInfo: "+120 FPS" },
  ],
  javaPacks: [
    { id: "1", name: "ZeroxPack 16x", description: "Faithful PvP pack 16x cho Java Edition", type: "PvP 16x", image: "", downloadLink: "#", fpsInfo: "+100 FPS" },
    { id: "2", name: "ZeroxSmooth 32x", description: "Smooth textures 32x, perfect cho PvP", type: "PvP 32x", image: "", downloadLink: "#", fpsInfo: "+60 FPS" },
    { id: "3", name: "ZeroxOverlay", description: "Crosshair + Hotbar custom overlay pack", type: "Overlay", image: "", downloadLink: "#", fpsInfo: "N/A" },
  ],
  players: [
    { id: "1", name: "ZeroxGaming", rank: "pro", category: "sword", score: 2500 },
    { id: "2", name: "ShadowKnight", rank: "diamond", category: "sword", score: 2100 },
    { id: "3", name: "PhoenixBlade", rank: "platinum", category: "sword", score: 1800 },
    { id: "4", name: "StormBreaker", rank: "silver", category: "crystal", score: 1500 },
    { id: "5", name: "DragonSlayer", rank: "bronze", category: "crystal", score: 1200 },
  ],
  users: [
    { username: "ZeroxGaming", password: "19032010", role: "admin" },
  ],
  socialLinks: [
    { platform: "Discord", url: "https://discord.gg/", icon: "discord" },
    { platform: "YouTube", url: "https://youtube.com/", icon: "youtube" },
    { platform: "TikTok", url: "https://tiktok.com/", icon: "tiktok" },
    { platform: "Facebook", url: "https://facebook.com/", icon: "facebook" },
  ],
};

export function getData(): SiteData {
  const stored = localStorage.getItem("zerox-data");
  if (stored) {
    const parsed = JSON.parse(stored);
    // Merge with defaults to add any new fields
    return { ...DEFAULT_DATA, ...parsed };
  }
  return { ...DEFAULT_DATA };
}

export function saveData(data: SiteData) {
  localStorage.setItem("zerox-data", JSON.stringify(data));
}

export function getLoggedInUser(): User | null {
  const stored = localStorage.getItem("zerox-user");
  if (stored) return JSON.parse(stored);
  return null;
}

export function loginUser(username: string, password: string): User | null {
  const data = getData();
  const user = data.users.find(u => u.username === username && u.password === password);
  if (user) {
    localStorage.setItem("zerox-user", JSON.stringify(user));
    return user;
  }
  return null;
}

export function registerUser(username: string, password: string): boolean {
  const data = getData();
  if (data.users.find(u => u.username === username)) return false;
  data.users.push({ username, password, role: "member" });
  saveData(data);
  return true;
}

export function logoutUser() {
  localStorage.removeItem("zerox-user");
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

export const RANK_CONFIG = {
  bronze: { label: "Đồng", color: "rank-bronze", icon: "🥉" },
  silver: { label: "Bạc", color: "rank-silver", icon: "🥈" },
  platinum: { label: "Bạch Kim", color: "rank-platinum", icon: "💎" },
  diamond: { label: "Kim Cương", color: "rank-diamond", icon: "💠" },
  pro: { label: "Pro", color: "rank-pro", icon: "👑" },
} as const;
