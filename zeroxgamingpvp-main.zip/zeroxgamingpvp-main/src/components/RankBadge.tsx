import { RANK_CONFIG } from "@/lib/store";

interface RankBadgeProps {
  rank: keyof typeof RANK_CONFIG;
  size?: "sm" | "md";
}

export default function RankBadge({ rank, size = "md" }: RankBadgeProps) {
  const config = RANK_CONFIG[rank];
  return (
    <span className={`inline-flex items-center gap-1 rounded-sm border font-display font-bold ${
      size === "sm" ? "text-xs px-2 py-0.5" : "text-sm px-3 py-1"
    } bg-${config.color}/10 border-${config.color}/30 text-${config.color}`}>
      {config.icon} {config.label}
    </span>
  );
}
