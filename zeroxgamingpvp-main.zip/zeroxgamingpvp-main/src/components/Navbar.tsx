import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { getLoggedInUser, logoutUser } from "@/lib/store";
import { Menu, X, LogIn, LogOut, User } from "lucide-react";

const NAV_ITEMS = [
  { label: "Trang chủ", path: "/" },
  { label: "RS Pack Bedrock", path: "/bedrock" },
  { label: "RS Java", path: "/java" },
  { label: "Box PvP", path: "/pvp" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const user = getLoggedInUser();

  const handleLogout = () => {
    logoutUser();
    window.location.reload();
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <Link to="/" className="font-display text-xl font-bold animate-rgb tracking-wider">
          ZeroxGaming
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`px-4 py-2 rounded-md font-body text-sm font-semibold tracking-wide transition-all duration-300 ${
                location.pathname === item.path
                  ? "bg-primary/10 text-primary text-glow-cyan"
                  : "text-muted-foreground hover:text-primary hover:bg-primary/5"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3">
              {user.role === "admin" && (
                <span className="text-xs font-display text-gold px-2 py-0.5 border border-gold/30 rounded-sm">
                  ADMIN
                </span>
              )}
              <Link to="/dashboard" className="flex items-center gap-2 text-sm font-body text-foreground hover:text-primary transition-colors">
                <User size={16} />
                {user.username}
              </Link>
              <button onClick={handleLogout} className="text-muted-foreground hover:text-destructive transition-colors">
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <Link to="/login" className="flex items-center gap-2 text-sm font-body text-primary hover:text-glow-cyan transition-all">
              <LogIn size={16} />
              Đăng nhập
            </Link>
          )}
        </div>

        {/* Mobile toggle */}
        <button onClick={() => setOpen(!open)} className="md:hidden text-foreground">
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl">
          <div className="flex flex-col p-4 gap-2">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setOpen(false)}
                className={`px-4 py-3 rounded-md font-body font-semibold transition-all ${
                  location.pathname === item.path
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-primary"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-border mt-2 pt-2">
              {user ? (
                <>
                  <Link to="/dashboard" onClick={() => setOpen(false)} className="flex items-center gap-2 px-4 py-3 text-foreground font-body">
                    <User size={16} />
                    {user.username}
                    {user.role === "admin" && <span className="text-xs text-gold ml-2">ADMIN</span>}
                  </Link>
                  <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-3 text-destructive font-body w-full text-left">
                    <LogOut size={16} /> Đăng xuất
                  </button>
                </>
              ) : (
                <Link to="/login" onClick={() => setOpen(false)} className="flex items-center gap-2 px-4 py-3 text-primary font-body">
                  <LogIn size={16} /> Đăng nhập
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
