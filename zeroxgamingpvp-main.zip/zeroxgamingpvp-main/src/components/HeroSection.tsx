import { motion } from "framer-motion";
import { getData } from "@/lib/store";
import SocialLinks from "./SocialLinks";

const DEFAULT_AVATAR = "/images/avatar.jpg";

export default function HeroSection() {
  const data = getData();

  return (
    <section className="relative min-h-screen flex items-center justify-center cyber-grid overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-secondary/5" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-[120px]" />

      <div className="relative z-10 text-center px-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="w-40 h-40 mx-auto rounded-full border-2 border-primary/50 box-glow-cyan overflow-hidden bg-muted flex items-center justify-center animate-float">
            <img src={data.avatarUrl || DEFAULT_AVATAR} alt="ZeroxGaming" className="w-full h-full object-cover scale-110" />
          </div>
        </motion.div>

        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-display text-5xl md:text-7xl tracking-wider rainbow-text font-bold mb-4"
        >
          ZeroxGaming
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="font-body text-lg md:text-xl text-muted-foreground max-w-xl mx-auto mb-8"
        >
          {data.bio}
        </motion.p>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <SocialLinks />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-16"
        >
          <div className="w-px h-16 bg-gradient-to-b from-primary/50 to-transparent mx-auto animate-pulse-glow" />
        </motion.div>
      </div>
    </section>
  );
}
