import { Pack } from "@/lib/store";
import { Download, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";

interface PackCardProps {
  pack: Pack;
  index: number;
}

export default function PackCard({ pack, index }: PackCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="group relative rounded-lg border border-border bg-card/50 overflow-hidden hover:border-glow-cyan transition-all duration-300"
    >
      {/* Image area */}
      <div className="h-40 bg-muted/50 relative overflow-hidden">
        {pack.image ? (
          <img src={pack.image} alt={pack.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center gradient-cyber">
            <span className="font-display text-3xl text-primary/30 group-hover:text-primary/50 transition-colors">
              📦
            </span>
          </div>
        )}
        {pack.fpsInfo && (
          <span className="absolute top-3 right-3 px-2 py-1 rounded-sm text-xs font-display font-bold bg-neon-green/20 text-neon-green border border-neon-green/30">
            {pack.fpsInfo}
          </span>
        )}
        <span className="absolute top-3 left-3 px-2 py-1 rounded-sm text-xs font-mono bg-primary/20 text-primary border border-primary/30">
          {pack.type}
        </span>
      </div>

      <div className="p-4">
        <h3 className="font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors mb-1">
          {pack.name}
        </h3>
        <p className="font-body text-sm text-muted-foreground mb-4 line-clamp-2">
          {pack.description}
        </p>
        <a
          href={pack.downloadLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary/10 border border-primary/30 text-primary font-body text-sm font-semibold hover:bg-primary/20 hover:box-glow-cyan transition-all duration-300"
        >
          <Download size={14} />
          Download
          <ExternalLink size={12} />
        </a>
      </div>
    </motion.div>
  );
}
