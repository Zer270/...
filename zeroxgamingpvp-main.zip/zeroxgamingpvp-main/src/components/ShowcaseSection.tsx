import { Link } from "react-router-dom";
import { getData, RANK_CONFIG } from "@/lib/store";
import { motion } from "framer-motion";
import { Sword, Diamond, Package, ArrowRight } from "lucide-react";

export default function ShowcaseSection() {
  const data = getData();

  const topSwordPlayers = data.players
    .filter((p) => p.category === "sword")
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  const topCrystalPlayers = data.players
    .filter((p) => p.category === "crystal")
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  return (
    <section className="py-10 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/3 to-transparent" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* RS Pack Bedrock */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0 }}
          >
            <Link
              to="/bedrock"
              className="group block rounded-xl border border-border bg-card/40 backdrop-blur-sm p-6 hover:border-primary/50 hover:box-glow-cyan transition-all duration-500 h-full"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center border border-primary/25">
                    <Package size={22} className="text-primary drop-shadow-[0_0_6px_hsl(var(--primary))]" />
                  </div>
                  <h3 className="font-display text-lg font-bold text-primary text-glow-cyan">RS Pack Bedrock</h3>
                </div>
                <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
              </div>

              <div className="space-y-3">
                {data.bedrockPacks.slice(0, 3).map((pack) => (
                  <div key={pack.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 group-hover:bg-muted/50 transition-colors">
                    {pack.image ? (
                      <img src={pack.image} alt={pack.name} className="w-10 h-10 rounded object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center text-lg">📦</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-display text-sm font-bold text-foreground truncate">{pack.name}</p>
                      <p className="text-xs text-muted-foreground font-body font-medium truncate">{pack.type}</p>
                    </div>
                    {pack.fpsInfo && (
                      <span className="text-xs font-mono text-neon-green whitespace-nowrap">{pack.fpsInfo}</span>
                    )}
                  </div>
                ))}
              </div>

              <p className="mt-4 text-xs text-muted-foreground font-body text-center group-hover:text-primary transition-colors">
                Xem tất cả {data.bedrockPacks.length} pack →
              </p>
            </Link>
          </motion.div>

          {/* RS Java */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
          >
            <Link
              to="/java"
              className="group block rounded-xl border border-border bg-card/40 backdrop-blur-sm p-6 hover:border-secondary/50 hover:box-glow-purple transition-all duration-500 h-full"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-secondary/15 flex items-center justify-center border border-secondary/25">
                    <Package size={22} className="text-secondary drop-shadow-[0_0_6px_hsl(var(--secondary))]" />
                  </div>
                  <h3 className="font-display text-lg font-bold text-secondary text-glow-purple">RS Java</h3>
                </div>
                <ArrowRight size={18} className="text-muted-foreground group-hover:text-secondary group-hover:translate-x-1 transition-all" />
              </div>

              <div className="space-y-3">
                {data.javaPacks.slice(0, 3).map((pack) => (
                  <div key={pack.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 group-hover:bg-muted/50 transition-colors">
                    {pack.image ? (
                      <img src={pack.image} alt={pack.name} className="w-10 h-10 rounded object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded bg-secondary/10 flex items-center justify-center text-lg">📦</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-display text-sm font-bold text-foreground truncate">{pack.name}</p>
                      <p className="text-xs text-muted-foreground font-body font-medium truncate">{pack.type}</p>
                    </div>
                    {pack.fpsInfo && (
                      <span className="text-xs font-mono text-neon-green whitespace-nowrap">{pack.fpsInfo}</span>
                    )}
                  </div>
                ))}
              </div>

              <p className="mt-4 text-xs text-muted-foreground font-body text-center group-hover:text-secondary transition-colors">
                Xem tất cả {data.javaPacks.length} pack →
              </p>
            </Link>
          </motion.div>

          {/* Box PvP */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <Link
              to="/pvp"
              className="group block rounded-xl border border-border bg-card/40 backdrop-blur-sm p-6 hover:border-gold/50 transition-all duration-500 h-full"
              style={{ boxShadow: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.boxShadow = "0 0 15px hsl(45 100% 55% / 0.2)")}
              onMouseLeave={(e) => (e.currentTarget.style.boxShadow = "none")}
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gold/15 flex items-center justify-center border border-gold/25">
                    <Sword size={22} className="text-gold drop-shadow-[0_0_6px_hsl(var(--gold))]" />
                  </div>
                  <h3 className="font-display text-lg font-bold text-gold">Box PvP</h3>
                </div>
                <ArrowRight size={18} className="text-muted-foreground group-hover:text-gold group-hover:translate-x-1 transition-all" />
              </div>

              {/* Top Sword */}
              <p className="text-xs font-display text-muted-foreground mb-2 flex items-center gap-1">
                <Sword size={12} /> Sword PvP
              </p>
              <div className="space-y-1.5 mb-4">
                {topSwordPlayers.map((player, i) => (
                  <div key={player.id} className="flex items-center gap-2 p-2 rounded bg-muted/30 text-sm">
                    <span className={`font-display font-bold w-5 text-center ${i === 0 ? "text-gold" : "text-muted-foreground"}`}>
                      #{i + 1}
                    </span>
                    <span className="font-body text-foreground flex-1 truncate">{player.name}</span>
                    <span className="font-mono text-xs text-primary">{player.score}</span>
                  </div>
                ))}
              </div>

              {/* Top Crystal */}
              <p className="text-xs font-display text-muted-foreground mb-2 flex items-center gap-1">
                <Diamond size={12} /> Crystal PvP
              </p>
              <div className="space-y-1.5">
                {topCrystalPlayers.map((player, i) => (
                  <div key={player.id} className="flex items-center gap-2 p-2 rounded bg-muted/30 text-sm">
                    <span className={`font-display font-bold w-5 text-center ${i === 0 ? "text-gold" : "text-muted-foreground"}`}>
                      #{i + 1}
                    </span>
                    <span className="font-body text-foreground flex-1 truncate">{player.name}</span>
                    <span className="font-mono text-xs text-secondary">{player.score}</span>
                  </div>
                ))}
              </div>

              <p className="mt-4 text-xs text-muted-foreground font-body text-center group-hover:text-gold transition-colors">
                Xem bảng xếp hạng đầy đủ →
              </p>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
