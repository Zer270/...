import { useState, useRef, useEffect } from "react";
import { getData } from "@/lib/store";
import { Volume2, VolumeX, Play, Pause } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function MusicPlayer() {
  const data = getData();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);

  const musicUrl = data.musicUrl;
  if (!musicUrl) return null;

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
    setPlaying(!playing);
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    audioRef.current.muted = !muted;
    setMuted(!muted);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-card/90 backdrop-blur-md border border-border shadow-lg"
    >
      <audio ref={audioRef} src={musicUrl} loop />
      <button onClick={toggle} className="text-primary hover:text-neon-green transition-colors">
        {playing ? <Pause size={20} /> : <Play size={20} />}
      </button>
      <button onClick={toggleMute} className="text-muted-foreground hover:text-foreground transition-colors">
        {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
      </button>
      {playing && (
        <div className="flex items-center gap-0.5 ml-1">
          {[0, 1, 2, 3].map((i) => (
            <motion.div
              key={i}
              className="w-1 bg-primary rounded-full"
              animate={{ height: [4, 14, 6, 12, 4] }}
              transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
            />
          ))}
        </div>
      )}
    </motion.div>
  );
}
