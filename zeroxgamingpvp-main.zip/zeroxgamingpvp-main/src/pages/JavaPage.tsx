import Navbar from "@/components/Navbar";
import PackCard from "@/components/PackCard";
import { getData } from "@/lib/store";
import { motion } from "framer-motion";

export default function JavaPage() {
  const data = getData();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-16 container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12 text-center">
          <h1 className="font-display text-4xl md:text-5xl font-black text-glow-purple text-secondary mb-3">
            RS Java
          </h1>
          <p className="font-body text-muted-foreground text-lg">Resource Packs & Texture Packs cho Java Edition</p>
        </motion.div>

        {data.javaPacks.length === 0 ? (
          <p className="text-center text-muted-foreground font-body">Chưa có pack nào.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.javaPacks.map((pack, i) => (
              <PackCard key={pack.id} pack={pack} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
