import { useState } from "react";
import Navbar from "@/components/Navbar";
import { getData, RANK_CONFIG } from "@/lib/store";
import { motion } from "framer-motion";
import { Sword, Diamond } from "lucide-react";

export default function PvPPage() {
  const data = getData();
  const [tab, setTab] = useState<"sword" | "crystal">("sword");

  const players = data.players
    .filter((p) => p.category === tab)
    .sort((a, b) => b.score - a.score);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-16 container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12 text-center">
          <h1 className="font-display text-4xl md:text-5xl font-black animate-rgb mb-3">Box PvP</h1>
          <p className="font-body text-muted-foreground text-lg">Bảng xếp hạng người chơi PvP</p>
        </motion.div>

        {/* Rank legend */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
          {(Object.entries(RANK_CONFIG) as [string, typeof RANK_CONFIG[keyof typeof RANK_CONFIG]][]).map(([key, val]) => (
            <span key={key} className={`inline-flex items-center gap-1 px-3 py-1 rounded-sm border text-xs font-display bg-rank-${key}/10 border-rank-${key}/30 text-rank-${key}`}>
              {val.icon} {val.label}
            </span>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-2 mb-8">
          <button
            onClick={() => setTab("sword")}
            className={`flex items-center gap-2 px-6 py-3 rounded-md font-display text-sm font-bold transition-all duration-300 ${
              tab === "sword"
                ? "bg-primary/15 border border-primary/40 text-primary box-glow-cyan"
                : "border border-border text-muted-foreground hover:text-primary hover:border-primary/30"
            }`}
          >
            <Sword size={18} /> Sword PvP
          </button>
          <button
            onClick={() => setTab("crystal")}
            className={`flex items-center gap-2 px-6 py-3 rounded-md font-display text-sm font-bold transition-all duration-300 ${
              tab === "crystal"
                ? "bg-secondary/15 border border-secondary/40 text-secondary box-glow-purple"
                : "border border-border text-muted-foreground hover:text-secondary hover:border-secondary/30"
            }`}
          >
            <Diamond size={18} /> Crystal PvP
          </button>
        </div>

        {/* Leaderboard */}
        <div className="max-w-2xl mx-auto">
          {players.length === 0 ? (
            <p className="text-center text-muted-foreground font-body">Chưa có người chơi nào.</p>
          ) : (
            <div className="space-y-2">
              {players.map((player, i) => {
                const rankConfig = RANK_CONFIG[player.rank];
                return (
                  <motion.div
                    key={player.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className={`flex items-center gap-4 p-4 rounded-lg border border-border bg-card/50 hover:border-glow-cyan transition-all duration-300 ${
                      i === 0 ? "border-gold/30 bg-gold/5" : ""
                    }`}
                  >
                    <span className={`font-display text-2xl font-black w-10 text-center ${
                      i === 0 ? "text-gold" : i === 1 ? "text-rank-silver" : i === 2 ? "text-rank-bronze" : "text-muted-foreground"
                    }`}>
                      #{i + 1}
                    </span>
                    <div className="flex-1">
                      <p className="font-display font-bold text-foreground">{player.name}</p>
                      <span className={`text-xs font-display text-rank-${player.rank}`}>
                        {rankConfig.icon} {rankConfig.label}
                      </span>
                    </div>
                    <span className="font-mono text-lg text-primary font-bold">{player.score}</span>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
