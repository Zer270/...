import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser, registerUser } from "@/lib/store";
import Navbar from "@/components/Navbar";
import { motion } from "framer-motion";

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!username || !password) { setError("Vui lòng nhập đầy đủ thông tin"); return; }

    if (isLogin) {
      const user = loginUser(username, password);
      if (user) { navigate("/dashboard"); window.location.reload(); }
      else setError("Sai tên đăng nhập hoặc mật khẩu");
    } else {
      const ok = registerUser(username, password);
      if (ok) {
        loginUser(username, password);
        navigate("/dashboard");
        window.location.reload();
      } else setError("Tên đăng nhập đã tồn tại");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-16 container mx-auto px-4 flex items-center justify-center min-h-screen">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md p-8 rounded-lg border border-border bg-card/50 box-glow-cyan"
        >
          <h2 className="font-display text-2xl font-bold text-center text-primary text-glow-cyan mb-6">
            {isLogin ? "Đăng Nhập" : "Đăng Ký"}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="font-body text-sm text-muted-foreground mb-1 block">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 rounded-md bg-muted border border-border font-body text-foreground focus:outline-none focus:border-primary focus:box-glow-cyan transition-all"
              />
            </div>
            <div>
              <label className="font-body text-sm text-muted-foreground mb-1 block">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-md bg-muted border border-border font-body text-foreground focus:outline-none focus:border-primary focus:box-glow-cyan transition-all"
              />
            </div>

            {error && <p className="text-destructive text-sm font-body">{error}</p>}

            <button
              type="submit"
              className="w-full py-3 rounded-md bg-primary/15 border border-primary/40 text-primary font-display font-bold tracking-wider hover:bg-primary/25 hover:box-glow-cyan transition-all duration-300"
            >
              {isLogin ? "ĐĂNG NHẬP" : "ĐĂNG KÝ"}
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground font-body mt-4">
            {isLogin ? "Chưa có tài khoản? " : "Đã có tài khoản? "}
            <button onClick={() => { setIsLogin(!isLogin); setError(""); }} className="text-primary hover:underline">
              {isLogin ? "Đăng ký" : "Đăng nhập"}
            </button>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
