import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { getData, saveData, getLoggedInUser, generateId, RANK_CONFIG, type Pack, type Player, type SiteData } from "@/lib/store";
import { Plus, Trash2, Save, Edit2, X, Image } from "lucide-react";
import { motion } from "framer-motion";

export default function DashboardPage() {
  const navigate = useNavigate();
  const user = getLoggedInUser();
  const [data, setData] = useState<SiteData>(getData());
  const [activeTab, setActiveTab] = useState<"bedrock" | "java" | "pvp" | "social" | "site">("bedrock");
  const [editingPack, setEditingPack] = useState<Pack | null>(null);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [packType, setPackType] = useState<"bedrock" | "java">("bedrock");

  useEffect(() => {
    if (!user) navigate("/login");
  }, [user, navigate]);

  if (!user) return null;
  const isAdmin = user.role === "admin";

  const save = (newData: SiteData) => {
    setData(newData);
    saveData(newData);
  };

  // Pack CRUD
  const addPack = (type: "bedrock" | "java") => {
    const newPack: Pack = { id: generateId(), name: "New Pack", description: "Mô tả pack", type: "PvP", image: "", downloadLink: "#", fpsInfo: "+60 FPS" };
    const key = type === "bedrock" ? "bedrockPacks" : "javaPacks";
    save({ ...data, [key]: [...data[key], newPack] });
    setEditingPack(newPack);
    setPackType(type);
  };

  const updatePack = (type: "bedrock" | "java", pack: Pack) => {
    const key = type === "bedrock" ? "bedrockPacks" : "javaPacks";
    save({ ...data, [key]: data[key].map(p => p.id === pack.id ? pack : p) });
    setEditingPack(null);
  };

  const deletePack = (type: "bedrock" | "java", id: string) => {
    const key = type === "bedrock" ? "bedrockPacks" : "javaPacks";
    save({ ...data, [key]: data[key].filter(p => p.id !== id) });
  };

  // Player CRUD
  const addPlayer = () => {
    const p: Player = { id: generateId(), name: "New Player", rank: "bronze", category: "sword", score: 1000 };
    save({ ...data, players: [...data.players, p] });
    setEditingPlayer(p);
  };

  const updatePlayer = (player: Player) => {
    save({ ...data, players: data.players.map(p => p.id === player.id ? player : p) });
    setEditingPlayer(null);
  };

  const deletePlayer = (id: string) => {
    save({ ...data, players: data.players.filter(p => p.id !== id) });
  };

  // Social CRUD
  const addSocial = () => {
    save({ ...data, socialLinks: [...data.socialLinks, { platform: "New Link", url: "#", icon: "discord" }] });
  };

  const updateSocial = (index: number, field: string, value: string) => {
    const links = [...data.socialLinks];
    (links[index] as any)[field] = value;
    save({ ...data, socialLinks: links });
  };

  const deleteSocial = (index: number) => {
    save({ ...data, socialLinks: data.socialLinks.filter((_, i) => i !== index) });
  };

  const tabs = isAdmin
    ? [
        { key: "bedrock", label: "Bedrock Packs" },
        { key: "java", label: "Java Packs" },
        { key: "pvp", label: "Box PvP" },
        { key: "social", label: "Social Links" },
        { key: "site", label: "Cài đặt" },
      ]
    : [
        { key: "bedrock", label: "Bedrock Packs" },
        { key: "java", label: "Java Packs" },
        { key: "pvp", label: "Box PvP" },
      ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-16 container mx-auto px-4">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-primary text-glow-cyan">
            Dashboard
          </h1>
          <p className="font-body text-muted-foreground">
            {isAdmin ? "Admin Panel — Quản lý toàn bộ website" : "Member — Xem thông tin"}
          </p>
          {isAdmin && <span className="text-xs font-display text-gold">👑 ADMIN</span>}
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 border-b border-border pb-4">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key as any)}
              className={`px-4 py-2 rounded-md font-body text-sm font-semibold transition-all ${
                activeTab === t.key
                  ? "bg-primary/15 text-primary border border-primary/30"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Bedrock Packs */}
        {activeTab === "bedrock" && (
          <PackList
            packs={data.bedrockPacks}
            type="bedrock"
            isAdmin={isAdmin}
            editingPack={editingPack}
            packType={packType}
            onAdd={() => addPack("bedrock")}
            onEdit={(p) => { setEditingPack(p); setPackType("bedrock"); }}
            onUpdate={(p) => updatePack("bedrock", p)}
            onDelete={(id) => deletePack("bedrock", id)}
            onCancel={() => setEditingPack(null)}
          />
        )}

        {/* Java Packs */}
        {activeTab === "java" && (
          <PackList
            packs={data.javaPacks}
            type="java"
            isAdmin={isAdmin}
            editingPack={editingPack}
            packType={packType}
            onAdd={() => addPack("java")}
            onEdit={(p) => { setEditingPack(p); setPackType("java"); }}
            onUpdate={(p) => updatePack("java", p)}
            onDelete={(id) => deletePack("java", id)}
            onCancel={() => setEditingPack(null)}
          />
        )}

        {/* PvP */}
        {activeTab === "pvp" && (
          <div>
            {isAdmin && (
              <button onClick={addPlayer} className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary/15 border border-primary/30 text-primary font-body text-sm font-semibold hover:bg-primary/20 transition-all mb-6">
                <Plus size={16} /> Thêm người chơi
              </button>
            )}
            <div className="space-y-2">
              {data.players.sort((a, b) => b.score - a.score).map((player) => (
                <div key={player.id} className="flex items-center gap-4 p-4 rounded-lg border border-border bg-card/50">
                  {editingPlayer?.id === player.id && isAdmin ? (
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-5 gap-3">
                      <input value={editingPlayer.name} onChange={(e) => setEditingPlayer({ ...editingPlayer, name: e.target.value })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Tên" />
                      <select value={editingPlayer.rank} onChange={(e) => setEditingPlayer({ ...editingPlayer, rank: e.target.value as any })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm">
                        {Object.entries(RANK_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
                      </select>
                      <select value={editingPlayer.category} onChange={(e) => setEditingPlayer({ ...editingPlayer, category: e.target.value as any })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm">
                        <option value="sword">Sword</option>
                        <option value="crystal">Crystal</option>
                      </select>
                      <input type="number" value={editingPlayer.score} onChange={(e) => setEditingPlayer({ ...editingPlayer, score: Number(e.target.value) })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Score" />
                      <div className="flex gap-2">
                        <button onClick={() => updatePlayer(editingPlayer)} className="px-3 py-2 rounded bg-neon-green/15 text-neon-green text-sm"><Save size={14} /></button>
                        <button onClick={() => setEditingPlayer(null)} className="px-3 py-2 rounded bg-muted text-muted-foreground text-sm"><X size={14} /></button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex-1">
                        <p className="font-display font-bold text-foreground">{player.name}</p>
                        <span className={`text-xs font-display text-rank-${player.rank}`}>
                          {RANK_CONFIG[player.rank].icon} {RANK_CONFIG[player.rank].label} • {player.category === "sword" ? "⚔️ Sword" : "💎 Crystal"}
                        </span>
                      </div>
                      <span className="font-mono text-primary font-bold">{player.score}</span>
                      {isAdmin && (
                        <div className="flex gap-2">
                          <button onClick={() => setEditingPlayer(player)} className="text-muted-foreground hover:text-primary"><Edit2 size={14} /></button>
                          <button onClick={() => deletePlayer(player.id)} className="text-muted-foreground hover:text-destructive"><Trash2 size={14} /></button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Social Links - Admin only */}
        {activeTab === "social" && isAdmin && (
          <div>
            <button onClick={addSocial} className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary/15 border border-primary/30 text-primary font-body text-sm font-semibold hover:bg-primary/20 transition-all mb-6">
              <Plus size={16} /> Thêm link
            </button>
            <div className="space-y-3">
              {data.socialLinks.map((link, i) => (
                <div key={i} className="flex items-center gap-3 p-4 rounded-lg border border-border bg-card/50">
                  <input value={link.platform} onChange={(e) => updateSocial(i, "platform", e.target.value)} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm w-32" placeholder="Platform" />
                  <input value={link.url} onChange={(e) => updateSocial(i, "url", e.target.value)} className="flex-1 px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="URL" />
                  <select value={link.icon} onChange={(e) => updateSocial(i, "icon", e.target.value)} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm">
                    <option value="discord">Discord</option>
                    <option value="youtube">YouTube</option>
                    <option value="tiktok">TikTok</option>
                    <option value="facebook">Facebook</option>
                    <option value="twitter">Twitter</option>
                    <option value="instagram">Instagram</option>
                    <option value="twitch">Twitch</option>
                  </select>
                  <button onClick={() => deleteSocial(i)} className="text-muted-foreground hover:text-destructive"><Trash2 size={14} /></button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Site settings - Admin only */}
        {activeTab === "site" && isAdmin && (
          <div className="max-w-lg space-y-6">
            <div>
              <label className="font-body text-sm font-bold text-muted-foreground mb-2 block">Ảnh đại diện</label>
              <div className="flex gap-3 items-center">
                <img
                  src={data.avatarUrl || "/images/avatar.jpg"}
                  alt="Avatar"
                  className="w-16 h-16 rounded-full object-cover border-2 border-primary/30"
                />
                <div className="flex-1 space-y-2">
                  <input
                    value={data.avatarUrl}
                    onChange={(e) => save({ ...data, avatarUrl: e.target.value })}
                    className="w-full px-4 py-3 rounded-md bg-muted border border-border font-body text-foreground focus:outline-none focus:border-primary transition-all text-sm"
                    placeholder="URL ảnh hoặc chọn file bên dưới"
                  />
                  <label className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary/15 border border-primary/30 text-primary font-body text-sm font-semibold hover:bg-primary/20 transition-all cursor-pointer w-fit">
                    <Image size={16} /> Chọn ảnh từ thiết bị
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            save({ ...data, avatarUrl: ev.target?.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>
            <div>
              <label className="font-body text-sm font-bold text-muted-foreground mb-2 block">Bio</label>
              <textarea
                value={data.bio}
                onChange={(e) => save({ ...data, bio: e.target.value })}
                className="w-full px-4 py-3 rounded-md bg-muted border border-border font-body text-foreground focus:outline-none focus:border-primary transition-all"
                rows={3}
              />
            </div>
            <div>
              <label className="font-body text-sm font-bold text-muted-foreground mb-2 block">🎵 Nhạc nền (URL MP3)</label>
              <input
                value={data.musicUrl || ""}
                onChange={(e) => save({ ...data, musicUrl: e.target.value })}
                className="w-full px-4 py-3 rounded-md bg-muted border border-border font-body text-foreground focus:outline-none focus:border-primary transition-all text-sm"
                placeholder="https://example.com/music.mp3"
              />
              <p className="text-xs text-muted-foreground mt-1 font-body">Dán link MP3 để phát nhạc nền trên website</p>
            </div>
            <p className="text-xs text-neon-green font-body font-bold">✅ Thay đổi được lưu tự động</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Pack list sub-component
function PackList({ packs, type, isAdmin, editingPack, packType, onAdd, onEdit, onUpdate, onDelete, onCancel }: {
  packs: Pack[];
  type: "bedrock" | "java";
  isAdmin: boolean;
  editingPack: Pack | null;
  packType: string;
  onAdd: () => void;
  onEdit: (p: Pack) => void;
  onUpdate: (p: Pack) => void;
  onDelete: (id: string) => void;
  onCancel: () => void;
}) {
  const [tempPack, setTempPack] = useState<Pack | null>(null);

  useEffect(() => {
    if (editingPack && packType === type) setTempPack(editingPack);
  }, [editingPack, packType, type]);

  return (
    <div>
      {isAdmin && (
        <button onClick={onAdd} className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary/15 border border-primary/30 text-primary font-body text-sm font-semibold hover:bg-primary/20 transition-all mb-6">
          <Plus size={16} /> Thêm pack
        </button>
      )}
      <div className="space-y-3">
        {packs.map((pack) => (
          <div key={pack.id} className="p-4 rounded-lg border border-border bg-card/50">
            {tempPack?.id === pack.id && packType === type && isAdmin ? (
              <div className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <input value={tempPack.name} onChange={(e) => setTempPack({ ...tempPack, name: e.target.value })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Tên pack" />
                  <input value={tempPack.type} onChange={(e) => setTempPack({ ...tempPack, type: e.target.value })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Loại (PvP, UI,...)" />
                  <input value={tempPack.fpsInfo || ""} onChange={(e) => setTempPack({ ...tempPack, fpsInfo: e.target.value })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="FPS Info" />
                  <input value={tempPack.downloadLink} onChange={(e) => setTempPack({ ...tempPack, downloadLink: e.target.value })} className="px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Link download" />
                </div>
                <textarea value={tempPack.description} onChange={(e) => setTempPack({ ...tempPack, description: e.target.value })} className="w-full px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="Mô tả" rows={2} />
                <div className="flex items-center gap-2">
                  <Image size={14} className="text-muted-foreground" />
                  <input value={tempPack.image} onChange={(e) => setTempPack({ ...tempPack, image: e.target.value })} className="flex-1 px-3 py-2 rounded bg-muted border border-border text-foreground font-body text-sm" placeholder="URL hình ảnh preview" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => onUpdate(tempPack)} className="flex items-center gap-1 px-4 py-2 rounded bg-neon-green/15 text-neon-green font-body text-sm"><Save size={14} /> Lưu</button>
                  <button onClick={onCancel} className="flex items-center gap-1 px-4 py-2 rounded bg-muted text-muted-foreground font-body text-sm"><X size={14} /> Hủy</button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                {pack.image && <img src={pack.image} alt={pack.name} className="w-16 h-16 rounded object-cover" />}
                <div className="flex-1">
                  <h3 className="font-display font-bold text-foreground">{pack.name}</h3>
                  <p className="text-sm text-muted-foreground font-body">{pack.description}</p>
                  <div className="flex gap-2 mt-1">
                    <span className="text-xs font-mono text-primary">{pack.type}</span>
                    {pack.fpsInfo && <span className="text-xs font-mono text-neon-green">{pack.fpsInfo}</span>}
                  </div>
                </div>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button onClick={() => onEdit(pack)} className="text-muted-foreground hover:text-primary"><Edit2 size={14} /></button>
                    <button onClick={() => onDelete(pack.id)} className="text-muted-foreground hover:text-destructive"><Trash2 size={14} /></button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
